package serverlog

import org.apache.spark._

object usecase7
{
    //Usecase-7 - Lookup with httpstatuscodemaster and get the count and description based on HTTP-Method
    //sample data: 
    //157.50.34.148 - - [27/Dec/2016:19:12:15 +0530] "GET /api/broker/bseindex/?callback=angular.callbacks._1a HTTP/1.1" 200 305 "https://equityboss.com/dashboard/" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"  def main(args:Array[String])
  
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setAppName("usecase7")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:///home/hduser/nginx/access.log",1)
    val statuscodemaster = sc.textFile("file:///home/hduser/sparkdata/httpstatuscodemaster.csv")
    val stmasmap = statuscodemaster.map(x => x.split("\\|")).map(x => (x(0),(x(1),x(2))))
    val pdata = rdd.map(r =>
    {
    val indstart = r.indexOf("\"")
    val indend = r.indexOf(" ",indstart+1)
    val stcodestrpos = r.indexOf("\"",indstart+1)
    val method = r.substring(indstart + 1,indend+1)
    val statuscode = r.substring(stcodestrpos+2, stcodestrpos+5)
    val methodstatuscode = method.trim().concat("-" + statuscode.trim())
    (statuscode,(method))
    
    }
    )   
    val joinrdd = pdata.join(stmasmap)    
    val finalrdd = joinrdd.map(x => x._1 + "- " +x._2._1+ "-" + x._2._2._1).distinct.sortBy(x => x.trim(),false)
    finalrdd.foreach(println)
  
  }
}