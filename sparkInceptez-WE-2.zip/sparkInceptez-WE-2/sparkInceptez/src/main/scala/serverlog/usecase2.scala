package main.scala.serverlog

import org.apache.spark._

object usecase2 
{
  //Usecase-2 - Get count of HTTP-Method(GET,POST,HEAD,etc) from $remote_user
  //sample data: 
  //157.50.34.148 - - [27/Dec/2016:19:12:15 +0530] "GET /api/broker/bseindex/?callback=angular.callbacks._1a HTTP/1.1" 200 305 "https://equityboss.com/dashboard/" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"  def main(args:Array[String])
  {
    val conf = new SparkConf().setAppName("usecase2").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:///home/hduser/nginx/access.log")    
    val rdcount = rdd.map(r => (r.substring(r.indexOf("\"")+1,r.indexOf(" ",r.indexOf("\"")+1)),1))
    rdcount.foreach(println)
    val rddcount1 = rdcount.countByKey()
    rddcount1.foreach(println)
  }
}