package main.scala.serverlog

import org.apache.spark._
//Usecase-1 - Get Unique/Distinct count of $remote_addr
//sample data: 
//157.50.34.148 - - [27/Dec/2016:19:12:15 +0530] "GET /api/broker/bseindex/?callback=angular.callbacks._1a HTTP/1.1" 200 305 "https://equityboss.com/dashboard/" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"  def main(args:Array[String])
  
object usecase1 
{
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setAppName("usecase1").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:/home/hduser/nginx/access.log")
    val rdd1 = rdd.map(x => x.substring(0,12))
    val disrdd = rdd1.distinct()
    println("Distinct count: " + disrdd.count)
  }
  
}