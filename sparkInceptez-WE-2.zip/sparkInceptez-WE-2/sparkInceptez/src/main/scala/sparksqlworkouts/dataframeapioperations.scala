package main.scala.sparksqlworkouts

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._


object dataframeapioperations
{
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("dataframeapioperations").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       import sqlContext.implicits._ 
       val df = sqlContext.read.option("header","true")
       .option("delimiter", ",")
       .csv("file:///home/hduser/sparkdata/trans")
       
       df.printSchema()
       
       print(s"Number of Partitions: $df.rdd.getNumPartitions")
       
       
       df.groupBy("state").count().show()
       //caching
       df.cache()
       df.unpersist()
       
       df.filter(df("payment") === "cash" && col("amount") >= 0)
       .groupBy($"productname", $"city", $"state")
       .agg($"productname", $"city", $"state",count($"transid"),sum($"amount"))
       .sort(asc("productname"),asc("city"))
       .show(true)      
  }
       
}