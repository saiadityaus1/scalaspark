package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.datastax.spark.connector._

object cassandraworkout 
{
  def main(args:Array[String])
  {
       val tblname = args(0).trim
       val conf = new SparkConf().setAppName("sparkcassandra").setMaster("local")
       conf.set("spark.cassandra.connection.host", "localhost")       
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)       
       val row = sc.cassandraTable("inceptez", tblname).select("emp_id","emp_name")
       row.foreach(println)       
       //import sqlContext.implicits._ 
       
       val df = sqlContext.read.format("org.apache.spark.sql.cassandra").options(Map("keyspace"
-> "inceptez", "table" -> "emp")).load()
       df.createOrReplaceTempView("emp")
       val sqldf = sqlContext.sql("SELECT * FROM emp")
       sqldf.show()
  }
       
}