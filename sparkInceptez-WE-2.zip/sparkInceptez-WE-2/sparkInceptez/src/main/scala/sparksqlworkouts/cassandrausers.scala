package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.datastax.spark.connector._

object cassandrausers
{
  
  case class empinfo(lastname:String,street:String,city:String,zip_code:Int,phones:String)
  case class users1(id:Int,firstname:String,einfo:List[empinfo])
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("cassandrainsert").setMaster("local")
       conf.set("spark.cassandra.connection.host", "localhost")       
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val rddemp = sc.textFile("file:///home/hduser/sparkdata/empinfo1.txt")
       val rddemp1 = rddemp.map(x => x.split(",")).map(x => (x(0).toInt,x(1),x(2),x(3),x(4),x(5).toInt,x(6)))
       val rddemp2 = rddemp1.map(x => ((x._1,x._2),empinfo(x._3,x._4,x._5,x._6,x._7)))
       val rddemp3 = rddemp2.combineByKey(List(_), (x:List[empinfo], y:empinfo) => y :: x, (x:List[empinfo], y:List[empinfo]) => x ::: y)
       val rddemp4 = rddemp3.map(x => users1(x._1._1,x._1._2,x._2))
       rddemp4.foreach(println)
       //val rddemp3 = rddemp2.map(x => users(x._1,fullname(x._2,x._3),Map("addr" -> address(x._4,x._5,x._6,x._7))))
       rddemp4.saveToCassandra("demo", "users1")
       println("Data written to cassandra successfully")    
  }    
}