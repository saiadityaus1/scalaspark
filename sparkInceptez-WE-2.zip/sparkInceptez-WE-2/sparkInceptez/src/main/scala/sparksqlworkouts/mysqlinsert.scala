package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.Dataset
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.JdbcRDD
import java.sql.{Connection, DriverManager, ResultSet}
import java.util.Properties

object mysqlinsert
{
  case class transcls (transid:String,transdt:String,custid:String,salesamt:Float,category:String,prodname:String,state:String,city:String,payment:String)

  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("sparkmysql").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       import sqlContext.implicits._ 
       //df_mysql.show()
       val prop = new Properties() 
       prop.put("user", "root")
       prop.put("password", "root")
       val rdd = sc.textFile("file:///home/hduser/sparkdata/trans")
       val header = rdd.first
       
       val rdd1 = rdd.filter(x => !x.contains(header))
       .map(_.split(","))
       .map(x =>
       transcls(x(0).trim(),x(1).trim().toString(), x(2).trim().toString,x(3).toFloat,x(4).trim(),x(5).trim(),x(6).trim(),x(7).trim(),x(8).trim()))
       val df = rdd1.toDF()
       
       //for each partition, separate con get created
       df.repartition(3).write.mode("overwrite").jdbc("jdbc:mysql://localhost/spark", "trans1", prop)
       println("Data inserted into mysql database..")
  }
       
}