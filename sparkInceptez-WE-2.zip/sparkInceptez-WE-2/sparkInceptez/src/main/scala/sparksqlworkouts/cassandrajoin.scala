package sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.datastax.spark.connector._


object cassandrainsert
{
  
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("cassandrainsert").setMaster("local")
       conf.set("spark.cassandra.connection.host", "localhost")       
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       
       val sqlContext = new SQLContext(sc)
              
       import sqlContext.implicits._ 
       val df = sqlContext.read.format("org.apache.spark.sql.cassandra").options(Map("keyspace"
-> "inceptez", "table" -> "customers")).load()
       df.createOrReplaceTempView("customers")       
       val df1 = sqlContext.read.format("org.apache.spark.sql.cassandra").options(Map("keyspace"
-> "inceptez", "table" -> "orders")).load()
       df1.createOrReplaceTempView("orders")
       val sqldf = sqlContext.sql("SELECT customers.id,customers.name,orders.amount FROM customers join orders on customers.id = orders.cust_id").show()
       
  }
       
}