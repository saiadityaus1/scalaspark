package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.elasticsearch.spark._ 



object esreadjson
{
  case class transcls (transid:String,transdt:String,custid:String,salesamt:String,category:String,prodname:String,city:String,state:String,payment:String)
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("esread").setMaster("local")
       conf.set("es.nodes", "localhost")
       conf.set("es.port", "9200")
       //conf.set("es.index.auto.create", "true");
       //conf.set("es.mapping.id","transid");
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlcontext = new SQLContext(sc)
       //val rdd = sc.esRDD("transinfo/trans").map(x=> x._2)
       val rdd1 = sc.esJsonRDD("empinfo/emp").map(x=> x._2)
       val df = sqlcontext.read.json(rdd1)
       df.show()
       //rdd1.foreach(println)
       /*val columns = rdd.take(1).flatMap(x => x.keys)
       import sqlcontext.implicits._
       val df = rdd.map(x => 
         {
         
         val mv = x.values.toList;
         (mv(0).toString,mv(1).toString,mv(2).toString,mv(3).toString,mv(4).toString,mv(5).toString,mv(6).toString,mv(7).toString,mv(8).toString)
         }).toDF(columns:_*)
      df.show()*/
         
  }
       
}