package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext


object hiveworkout 
{
  def main(args:Array[String])
  {
    
        //val warehouseLocation = "file:${system:user.dir}/spark-warehouse"
       val conf = new SparkConf().setAppName("sparkmysql").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
       hiveContext.sql("CREATE TABLE IF NOT EXISTS employeespark(id INT, name STRING, age INT) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n'")
       hiveContext.sql("LOAD DATA LOCAL INPATH '/home/hduser/employee.txt' INTO TABLE employeespark")
       val result = hiveContext.sql("FROM employeespark SELECT id, name, age")
       result.show()
       
  }
       
}