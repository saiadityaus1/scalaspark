package main.scala.sparksqlworkouts

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql._
import com.sun.corba.se.impl.orbutil.CacheTable

object datasetoperations
{
  case class DeviceIoTData (
  battery_level: Long,
  c02_level: Long,
  cca2: String,
  cca3: String,
  cn: String,
  device_id: Long,
  device_name: String,
  humidity: Long,
  ip: String,
  latitude: Double,
  longitude: Double,
  scale: String,
  temp: Long,
  timestamp: Long
  )
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("datasetoperations").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       import sqlContext.implicits._ 
       val ds = sqlContext.read.json("file:/home/hduser/sparkdata/iot_devices.json").as[DeviceIoTData]
       ds.show()
       // filter out all devices whose temperature exceed 25 degrees and generate 
       // another Dataset with three fields that of interest and then display 
       // the mapped Dataset
      
      val ds1 = ds.filter(d => d.temp > 25)
      .map(d => (d.temp, d.device_name, d.cca3))
      
      // Using the standard Spark commands, take() and foreach(), print the first 
       // 10 rows of the Datasets.
       ds1.take(10).foreach(println)
       ds1.printSchema()
       ds1.show()
       
       //dataset.write.mode(SaveMode.Overwrite).saveAsTable("iot_device")
       //val rdd = dataset.rdd
       
  }
       
}