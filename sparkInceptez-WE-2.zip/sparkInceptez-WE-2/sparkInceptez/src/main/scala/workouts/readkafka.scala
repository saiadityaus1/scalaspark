package main.scala.workouts


import java.util.concurrent._
import java.util.{Collections, Properties}

import kafka.consumer.KafkaStream
import kafka.utils.Logging
import org.apache.kafka.clients.consumer.{ConsumerConfig, KafkaConsumer}

import scala.collection.JavaConversions._

object readkafka {
  
  def main(args:Array[String])
  {
                val props = new Properties()
                
                props.put("bootstrap.servers", "localhost:9092");
                props.put("group.id", "grp1");
                props.put("enable.auto.commit", "true");
                props.put("auto.commit.interval.ms", "1000");
                props.put("session.timeout.ms", "30000");
                props.put("key.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
                props.put("value.deserializer","org.apache.kafka.common.serialization.StringDeserializer");
                val consumer = new KafkaConsumer[String, String](props);
                consumer.subscribe(java.util.Collections.singletonList("tr43"));
                System.out.println("Subscribed to topic ");
                var i = 0
                while (true) {
                val records = consumer.poll(1000)
                for (record <- records) {
                    System.out.println("Received message: (" + record.key() + ", " + record.value() + ") at offset " + record.offset())
                }
          }     
  }
}