package workouts

import org.apache.spark._

object broadcast {
  
  def main(args:Array[String])
  {
      val conf = new SparkConf().setAppName("usecase8").setMaster("local")                                                                                      
      val sc = new SparkContext(conf)
      sc.setLogLevel("ERROR")
      
  }
}