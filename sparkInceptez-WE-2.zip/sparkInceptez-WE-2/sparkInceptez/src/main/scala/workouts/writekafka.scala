package main.scala.workouts

import org.apache.spark._
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

object writekafka {
  
  def main(args:Array[String])
  {
      val conf = new SparkConf().setAppName("writekafka").setMaster("local")
      val sc = new SparkContext(conf)
      sc.setLogLevel("ERROR")
      val input = sc.textFile("file:/home/hduser/sparkdata/emp3.txt")
      input.foreachPartition(
          partitionOfRecords =>
            {
                val props = new Properties()
                props.put("bootstrap.servers", "localhost:9092");
                props.put("client.id", "DemoProducer");
                props.put("key.serializer", "org.apache.kafka.common.serialization.IntegerSerializer");
                props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
                val producer = new KafkaProducer[String, String](props);
                partitionOfRecords.foreach
                {
                    case x:String=>{
                        println(x)

                        val message=new ProducerRecord[String, String]("tr43",null,x)
                        producer.send(message)
                    }
                }
                producer.close
          })
  }
}