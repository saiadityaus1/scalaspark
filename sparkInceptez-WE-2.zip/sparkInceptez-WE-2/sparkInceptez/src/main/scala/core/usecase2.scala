package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase2 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase2")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("hdfs://localhost:54310/user/hduser/Inceptez2.txt")
    val filtercnt1 = rdd.filter(_.contains("Inceptez")).count()
    val filtercnt2 = rdd.filter(x => ! x.contains("Inceptez")).count()
    println(s"Inceptez filter count : $filtercnt1")
    println(s"Inceptez filter count : $filtercnt2")
  }
}