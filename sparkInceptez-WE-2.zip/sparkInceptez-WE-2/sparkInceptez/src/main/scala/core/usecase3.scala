package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase3 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase3")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.parallelize(List("We", "Are" ,"Learning" , "Hadoop" , "From" , "Inceptez" , "We", "Are" ,"Learning" , "Spark" , "From" , "Inceptez.com" , "hadoop" , "HADOOP"))
    val wordcount = rdd.count
    println(s"Number of words : $wordcount")
    val wc1 = rdd.filter(x => !x.toLowerCase().contains("hadoop")).count
    println(s"Number of words that does not have hadoop keyword : $wc1")
  }
}