package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase6 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase6")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:///home/hduser/hadoophortonworks6.txt")
    val rdd1 = rdd.mapPartitionsWithIndex{(i,x) => if(i==0) x.drop(1) else x }
    val rdd2 = rdd1.map(_.split(',')).map(x =>(x(0),x(1),x(2),x(1).toInt + x(2).toInt))
    rdd2.saveAsTextFile("hdfs://localhost:54310/user/hduser/hpdcd/task6output")  
  }
}