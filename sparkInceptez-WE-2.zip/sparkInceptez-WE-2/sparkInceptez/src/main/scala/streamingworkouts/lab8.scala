package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe

object lab8 {
  
  def main(args:Array[String])
  {
        //var master = Option(args(0)).getOrElse("local[*]")
        val sparkConf = new SparkConf().setAppName("kafkalab")
        val sparkcontext = new SparkContext(sparkConf)
        sparkcontext.setLogLevel("ERROR")
        val ssc = new StreamingContext(sparkcontext, Seconds(10))
        ssc.checkpoint("file:///tmp/checkpointdir")
        val kafkaParams = Map[String, Object](
          "bootstrap.servers" -> "localhost:9092",
          "key.deserializer" -> classOf[StringDeserializer],
          "value.deserializer" -> classOf[StringDeserializer],
          "group.id" -> "kafkatest1",
          "auto.offset.reset" -> "latest"
          )

        val topics = Array("kafkatopic")
        val stream = KafkaUtils.createDirectStream[String, String](
          ssc,
          PreferConsistent,
          Subscribe[String, String](topics, kafkaParams)
        )
        val inputStream = stream.map(record => (record.value))
        //val inputStream = kafkastream.map(rec => rec._2);
        //inputStream.print()
         
        val parsedata = (str:String) => {
        val sarr = str.split("[,]");
        if(sarr.length == 9)
                        "{\"txnid\":" + sarr(0) +
                        ",\"txndate\":\"" + sarr(1) + "\",\"custid\":\"" + sarr(2) +
                        "\",\"price\":\"" + sarr(3) + "\",\"product\":\"" + sarr(4) +
                        "\",\"category\":\"" + sarr(5) + "\",\"city\":\"" + sarr(6) +
                        "\",\"state\":\"" + sarr(7) + "\",\"paymenttype\":\"" + sarr(8) +
                        "\"}";
          else
              "";
        }
       val parsedStream = inputStream.mapPartitions
       {
              rdd => rdd.map(parsedata).filter( x => !x.equals(""))
       }
       parsedStream.print() 
       ssc.start()
       ssc.awaitTermination()
    
  }
  
}