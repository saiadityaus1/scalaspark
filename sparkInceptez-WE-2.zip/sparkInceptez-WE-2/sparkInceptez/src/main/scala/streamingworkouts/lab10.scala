package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import java.sql.{Connection, DriverManager, ResultSet}

object lab10 {
  case class trans(transid: String, transdate: String, custid: String, salesamt: Float, category: String, prodname: String, state: String, city: String,payment: String)

  def main(args:Array[String])
  {
    val sparkConf = new SparkConf().setAppName("lab10KafkatoMysql")
        val sparkcontext = new SparkContext(sparkConf)
        val ssc = new StreamingContext(sparkcontext, Seconds(10))
        ssc.checkpoint("file:///tmp/checkpointdir")
        val kafkaParams = Map[String, Object](
          "bootstrap.servers" -> "localhost:9092",
          "key.deserializer" -> classOf[StringDeserializer],
          "value.deserializer" -> classOf[StringDeserializer],
          "group.id" -> "kafkatest1",
          "auto.offset.reset" -> "earliest"
          )

        val topics = Array("kafkatopic")
        val stream = KafkaUtils.createDirectStream[String, String](
          ssc,
          PreferConsistent,
          Subscribe[String, String](topics, kafkaParams)
        )

        val kafkastream = stream.map(record => (record.key, record.value))
        val inputStream = kafkastream.map(rec => rec._2);
        //write data into mysql
        inputStream.foreachRDD (rdd1 => 
          {
            if(!rdd1.isEmpty)
            {
              rdd1.foreachPartition(rdd => 
              {
                val rdd2 = rdd.map(_.split(",")).map(x => trans(x(0).trim(),x(1).trim().toString(), x(2).trim().toString,x(3).toFloat,x(4).trim(),x(5).trim(),x(6).trim(),x(7).trim(),x(8).trim()))
                val conn = DriverManager.getConnection("jdbc:mysql://localhost/spark","root","root")
                val del = conn.prepareStatement("INSERT INTO trans (transid,transdt,custid,salesamt,category,prodname,city,state,payment) VALUES (?,?,?,?,?,?,?,?,?)")
                for (trans <- rdd2) 
                 {
                    del.setString (1, trans.transid)
                    del.setString(2, trans.transdate)
                    del.setString(3, trans.custid)
                    del.setFloat(4, trans.salesamt)
                    del.setString(5, trans.category)
                    del.setString(6, trans.prodname)
                    del.setString(7, trans.city)
                    del.setString(8, trans.state)
                    del.setString(9, trans.payment)
                    del.executeUpdate
                }
                  
              })
            }
            })
        
        ssc.start()
        ssc.awaitTermination()    
  }
  
}