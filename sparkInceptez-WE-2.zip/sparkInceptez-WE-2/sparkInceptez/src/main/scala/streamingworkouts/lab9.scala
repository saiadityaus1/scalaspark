package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import java.util.HashMap
import org.apache.kafka.clients.producer.{KafkaProducer,
ProducerConfig, ProducerRecord}

object lab9 {
  def main(args:Array[String])
  {
        val sparkConf = new SparkConf().setAppName("kafkalab").setMaster("local[*]")
        val sparkcontext = new SparkContext(sparkConf)
        sparkcontext.setLogLevel("ERROR")
        val ssc = new StreamingContext(sparkcontext, Seconds(10))
        ssc.checkpoint("file:///tmp/checkpointdir")
        val kafkaParams = Map[String, Object](
          "bootstrap.servers" -> "192.168.247.131:9092",
          "key.deserializer" -> classOf[StringDeserializer],
          "value.deserializer" -> classOf[StringDeserializer],
          "group.id" -> "kafkatest1",
          "auto.offset.reset" -> "latest"
          )

        val topics = Array("prodsalestopic")
        val stream = KafkaUtils.createDirectStream[String, String](
          ssc,
          PreferConsistent,
          Subscribe[String, String](topics, kafkaParams)
        )  
        
        val kafkastream = stream.map(record => (record.key, record.value))
        val inputStream = kafkastream.map(rec => rec._2);
        val parsedata = (str:String) => {
        val sarr = str.split("[,]");
        if(sarr.length == 9)
                        "{\"txnid\":" + sarr(0) +
                        ",\"txndate\":\"" + sarr(1) + "\",\"custid\":\"" + sarr(2) +
                        "\",\"price\":\"" + sarr(3) + "\",\"product\":\"" + sarr(4) +
                        "\",\"category\":\"" + sarr(5) + "\",\"city\":\"" + sarr(6) +
                        "\",\"state\":\"" + sarr(7) + "\",\"paymenttype\":\"" + sarr(8) +
                        "\"}";
          else
              "";
        }
        val parsedStream = inputStream.mapPartitions
        {
              rdd => rdd.map(parsedata).filter( x => !x.equals(""))
        }
        parsedStream.print()    
        
        // write into another kafka topic
        
        parsedStream.foreachRDD(
        rdd => {
          rdd.foreachPartition(rows => {
          val props = new HashMap[String, Object]()
                          props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"192.168.247.131:9092")
                          props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                            "org.apache.kafka.common.serialization.StringSerializer")
                          props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                            "org.apache.kafka.common.serialization.StringSerializer")
                          val producer = new KafkaProducer[String,String](props)
                          rows.foreach(row => { val message=new ProducerRecord[String,String]("kafkatopic1",null,row.toString());
                                                   producer.send(message)
                      })
                 })
        })
        
        ssc.start()
        ssc.awaitTermination()
  }
}