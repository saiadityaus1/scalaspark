package main.scala.sparksqlworkouts

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext


object csvoperations
{
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("csvoperations").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       // import sqlContext.implicits._ 
       val df = sqlContext.read.option("header","true")
       .option("delimiter", ",")
       .option("inferschema", "true")
       .csv("file:///home/hduser/sparkdata/trans")
       df.printSchema
       df.createOrReplaceTempView("transtbl")
       val df1 = sqlContext.sql("select state,city,sum(amount) from transtbl group by state,city order by state")
       df1.show(100,false)
       //print(df1.rdd.getNumPartitions)
       //df1.repartition(1).write.csv("file:///home/hduser/transout")
       print("Write Completed")
  }
       
}