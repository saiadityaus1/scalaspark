package main.scala.sparksqlworkouts

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql._
import org.apache.spark.sql.functions.explode

object xmloperations
{
  
  def main(args:Array[String])
  {
       //xml data read,parse,save as csv file
       val conf = new SparkConf().setAppName("xmloperations").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       import sqlContext.implicits._
       val df = sqlContext.read.format("com.databricks.spark.xml").option("rowTag", "Transaction").load("file:/home/hduser/sparkdata/transactions.xml")
       df.printSchema()
       //df.show()
       val flattened = df.withColumn("LineItem", explode($"RetailTransaction.LineItem"))
       val selectedData = flattened.select($"RetailStoreID",$"WorkstationID",$"OperatorID._OperatorName" as "OperatorName",$"OperatorID._VALUE" as "OperatorID",$"CurrencyCode",$"RetailTransaction.ReceiptDateTime",$"RetailTransaction.TransactionCount",$"LineItem.SequenceNumber",$"LineItem.Tax.TaxableAmount")
       selectedData.show(100,false)
       //selectedData.write.format("com.databricks.spark.csv").option("header", "true").mode("overwrite").save("file:/home/hduser/sparkdata/transactions.csv")
  }
}