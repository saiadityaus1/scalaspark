package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object mysqlworkout 
{
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("sparkmysql").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       val df_mysql = sqlContext.read.format("jdbc")
       .option("url", "jdbc:mysql://localhost/spark")
       .option("driver", "com.mysql.jdbc.Driver")
       .option("dbtable", "trans")
       .option("user", "root")
       .option("password", "root")
       .load()       
       val jdbcDF = sqlContext.read.format("jdbc").options(
        Map("url" ->  "jdbc:mysql://localhost/spark?user=root&password=root",
        "dbtable" -> "spark.trans",
        "fetchSize" -> "10000",
        "partitionColumn" -> "transid", "lowerBound" -> "0", "upperBound" -> "90000", "numPartitions" -> "10"
        )).load()
        jdbcDF.explain(true)
        
        jdbcDF.show(true)
        df_mysql.createOrReplaceTempView("txns")
        var str = "sports"
        val df3 = sqlContext.sql("select transid,transdt,'test' tempcol from txns where category='"+ str + "'")
        df3.show()
  }
       
}