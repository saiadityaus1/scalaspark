package sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.datastax.spark.connector._


object cassandrajoin
{
  case class emp(emp_id:Int,emp_name:String,emp_city:String,emp_sal:Int,emp_phone:Int)
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("cassandrainsert").setMaster("local")
       conf.set("spark.cassandra.connection.host", "localhost")       
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")       
        val dfemp = sc.textFile("file:///home/hduser/sparkdata/.txt")
       val dfemp1 = dfemp.map(_.split(",")).map(x =>
emp(x(0).trim.toInt,x(1).trim().toString(), x(2).trim.toString,x(3).toInt,x(4).toInt))
       
       dfemp1.saveToCassandra("inceptez", "emp")       
       println("Data written to cassandra successfully")
       
  }
       
}