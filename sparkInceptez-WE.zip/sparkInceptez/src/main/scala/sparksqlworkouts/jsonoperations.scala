package main.scala.sparksqlworkouts

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql._
import org.apache.spark.sql.functions._

object jsonoperations
{
  case class DeviceIoTData (
  battery_level: Long,
  c02_level: Long,
  cca2: String,
  cca3: String,
  cn: String,
  device_id: Long,
  device_name: String,
  humidity: Long,
  ip: String,
  latitude: Double,
  longitude: Double,
  scale: String,
  temp: Long,
  timestamp: Long
  )
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("jsonoperations").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       import sqlContext.implicits._ 
       val df = sqlContext.read.json("file:/home/hduser/sparkdata/iot_devices.json")
       df.write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter", "~").csv("file:/home/hduser/sparkdata/iot_devices")
  }
       
}