package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.Dataset
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import java.util.Properties

object mysqlinsertdf
{
  case class transcls (transid:String,transdt:String,custid:String,salesamt:Float,category:String,prodname:String,state:String,city:String,payment:String)

  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("sparkmysql").setMaster("local")
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val sqlContext = new SQLContext(sc)
       val prop = new Properties() 
       prop.put("user", "root")
       prop.put("password", "root")
       val df = sqlContext.read.option("header", "true").csv("file:///home/hduser/sparkdata/trans")
       //for each partition, separate con get created
       df.repartition(3).write.mode("overwrite").jdbc("jdbc:mysql://localhost/spark", "trans1", prop)
       println("Data inserted into mysql database..")
  }
       
}