package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import com.datastax.spark.connector._

object cassandraudt
{
  
   case class employee(id:Int,city:String,name:String)
  
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("cassandrainsert").setMaster("local")
       conf.set("spark.cassandra.connection.host", "localhost")       
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")
       val rddemp = sc.textFile("file:///home/hduser/sparkdata/empinfo.txt")
       val rddemp2 = rddemp.map(x => x.split(",")).map(x => (x(0).toInt,x(1),x(2),x(3)))
       val rddemp3 = rddemp2.map(x => employee(x._1,x._2,x._3))
       rddemp3.saveToCassandra("demo", "employee")
       println("Data written to cassandra successfully")    
  }    
}