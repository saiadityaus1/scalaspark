package main.scala.sparksqlworkouts

import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.elasticsearch.spark._ 


object esinsert
{
  case class transcls (transid:String,transdt:String,custid:String,salesamt:Float,category:String,prodname:String,city:String,state:String,payment:String)
  def main(args:Array[String])
  {
       val conf = new SparkConf().setAppName("esinsert").setMaster("local")
       conf.set("es.nodes", "localhost")
       conf.set("es.port", "9200")
       conf.set("es.index.auto.create", "true");
       conf.set("es.mapping.id","transid");
       val sc = new SparkContext(conf)
       sc.setLogLevel("ERROR")       
        val rdd = sc.textFile("file:///home/hduser/sparkdata/sampledata1.txt")
       val rddes = rdd.map(_.split(",")).map(x =>
       transcls(x(0).trim(),x(1).trim().toString(), x(2).trim().toString,x(3).toFloat,x(4).trim(),x(5).trim(),x(6).trim(),x(7).trim(),x(8).trim()))
       rddes.saveToEs("transinfo/trans")
       println("Data written to Elasticsearch successfully")
       
  }
       
}