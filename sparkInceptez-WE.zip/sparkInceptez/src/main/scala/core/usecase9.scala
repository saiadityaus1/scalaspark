package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase9 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase9")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("/spark3/sparkdir1/file1.txt,/spark3/sparkdir2/file2.txt,/spark3/sparkdir3/file3.txt").flatMap(_.split(" ")).map(_.trim())
    val rdd1 = rdd.mapPartitions(partition => 
    {
      val words = Array("a","the","an","as","a","with","this","these","is","are","in","for","to","and","The","of");
      partition.filter(x => words.contains(x))
    })
    val rdd2 = rdd1.map((_,1)).reduceByKey(_+_).coalesce(1).sortBy(x=>x._1,false)
    import org.apache.hadoop.io.compress.GzipCodec
    rdd2.saveAsTextFile("taskoutput9",classOf[GzipCodec])
  }
}