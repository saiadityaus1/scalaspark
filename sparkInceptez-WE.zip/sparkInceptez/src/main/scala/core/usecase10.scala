package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase10 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase10")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val emp = sc.textFile("/user/hduser/EmployeeName.csv").map(_.split(",")).map(x => (x(0),(x(1))))
    val empsal = sc.textFile("/user/hduser/EmployeeSalary.csv").map(_.split(",")).map(x => (x(0),(x(1))))
    val grpbykey = emp.join(empsal).map(x => (x._2._2,(x._2._1,x._2._2))).groupByKey().collect
    val rddbykey = grpbykey.map{case(k,v) =>  k->sc.makeRDD(v.toSeq)}
    rddbykey.foreach{case(k,v) => v.saveAsTextFile("spark5/Employee"+k)}
  }
}