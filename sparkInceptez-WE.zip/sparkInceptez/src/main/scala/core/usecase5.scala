package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase5 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase5")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd1 = sc.textFile("hdpcd/dir5A,hpdcd/dir5B,hpdcd/dir5C")
    val rdd2 = rdd1.filter(_.contains("Hadoop"))
    rdd2.persist(org.apache.spark.storage.StorageLevel.MEMORY_ONLY)
    println("Count of Hadoop words in all 3 files : " + rdd2.count)
    val rdd3 = rdd2.map(x => (x,x.length))
    rdd3.foreach(println)    
  }
}