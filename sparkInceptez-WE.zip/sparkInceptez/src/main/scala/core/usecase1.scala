package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase1 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setAppName("usecase1")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("hdfs://localhost:54310/user/hduser/Inceptez1.txt")
    val linecount = rdd.count()
    println(s"LineCount : $linecount")
  }
}