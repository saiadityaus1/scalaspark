package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase8 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase8")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val broadcastrdd = sc.textFile("file:///home/hduser/Remove.txt").flatMap(_.split(",")).map(_.trim().toLowerCase)
    val brdcast = sc.broadcast(broadcastrdd.collect)
    val rdd = sc.textFile("file:///home/hduser/Content.txt")
    val rdd1 = rdd.flatMap(_.split(" ")).map(_.trim())
    val rdd2 = rdd1.filter(y => !brdcast.value.contains(y.toLowerCase)).map((_,1)).reduceByKey(_+_)
    rdd2.saveAsTextFile("/user/task8output")
  }
}