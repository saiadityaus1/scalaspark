package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase4 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase4")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd1 = sc.textFile("hdfs://localhost:54310/user/hduser/uc4/Inceptez4A.txt")
    val rdd2 = sc.textFile("hdfs://localhost:54310/user/hduser/uc4/Inceptez4B.txt")
    val rdd3 = sc.textFile("hdfs://localhost:54310/user/hduser/uc4/Inceptez4C.txt")
    val rdd4 = rdd1.union(rdd2).union(rdd3).flatMap(_.split(" "))
    println("Count of words in all 3 files : " + rdd4.count)
  }
}