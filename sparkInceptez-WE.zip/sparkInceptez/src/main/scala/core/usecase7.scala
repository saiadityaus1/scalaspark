package main.scala.core

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object usecase7 {
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setMaster("local").setAppName("usecase7")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val empmgr = sc.textFile("/user/hduser/EmployeeManager.csv").map(_.split(",")).map(x => (x(0),(x(1))))
    val emp = sc.textFile("/user/hduser/EmployeeName.csv").map(_.split(",")).map(x => (x(0),(x(1))))
    val empsal = sc.textFile("/user/hduser/EmployeeSalary.csv").map(_.split(",")).map(x => (x(0),(x(1))))
    val rdd = emp.join(empmgr).map(x => (x._1,(x._2._1,x._2._2)))
    val finalrdd = rdd.join(empsal).map(x => (x._1,x._2._1._1,x._2._1._2,x._2._2)).coalesce(1).sortBy(_._1)
    finalrdd.saveAsTextFile("taskoutput7")
  }
}