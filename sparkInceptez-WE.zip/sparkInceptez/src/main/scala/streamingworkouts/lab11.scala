package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.elasticsearch.spark.streaming._ 
import java.util.Date

object lab11 {
  
case class transRow(transid: String, transdate: Date, custid: String, salesamt: Float, category: String, prodname: String, state: String, city: String,payment: String)
  
  def main(args:Array[String])
  {
        val sparkConf = new SparkConf().setAppName("kafkalab").setMaster("local[*]")
         sparkConf.set("es.nodes", "localhost")
         sparkConf.set("es.port", "9200")
         sparkConf.set("es.index.auto.create", "true");
         sparkConf.set("es.mapping.id","transid");
        val sparkcontext = new SparkContext(sparkConf)        
       
        
        val ssc = new StreamingContext(sparkcontext, Seconds(10))
        ssc.checkpoint("checkpointdir")
        val kafkaParams = Map[String, Object](
          "bootstrap.servers" -> "localhost:9092",
          "key.deserializer" -> classOf[StringDeserializer],
          "value.deserializer" -> classOf[StringDeserializer],
          "group.id" -> "kafkatest1",
          "auto.offset.reset" -> "earliest"
          )

        val topics = Array("kafkatopic")
        val stream = KafkaUtils.createDirectStream[String, String](
          ssc,
          PreferConsistent,
          Subscribe[String, String](topics, kafkaParams)
        )

        val kafkastream = stream.map(record => (record.key, record.value))
        val inputStream = kafkastream.map(rec => rec._2);
        val ds1 = inputStream.map(_.split(",")).map(x => 
          {
          var trandt = new Date()
          transRow(x(0).trim(),trandt, x(2).trim().toString,x(3).toFloat,x(4).trim(),x(5).trim(),x(6).trim(),x(7).trim(),x(8).trim())
          })
        ds1.saveToEs("empinfo/docs")
        ssc.start()
        ssc.awaitTermination()    

  }
}