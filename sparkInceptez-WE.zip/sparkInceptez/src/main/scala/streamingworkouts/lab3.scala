package streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._

object lab3 {
  
  def main(args:Array[String])
  {
   
      def updateFunction(newValues: Seq[(Int)], runningCount: Option[(Int)]): Option[(Int)] = {
      var result: Option[(Int)] = null
      if(newValues.isEmpty){ //check if the key is present in new batch if not then return the old values
      result=Some(runningCount.get)
      }
      else
      {
        newValues.foreach 
        { x => 
          {// if we have keys in new batch ,iterate over them and add it
            if(runningCount.isEmpty)
            {
              result=Some(x)// if no previous value return the new one
            }
            else
            {
              result=Some(x+runningCount.get) // update and return the value
            }
        }
      }
      }
      result
      }
    val sparkConf = new SparkConf().setAppName("wordcountwithupdatekey").setMaster("local[*]")
    val sparkcontext = new SparkContext(sparkConf)
    sparkcontext.setLogLevel("ERROR")
    // Create the context
    val ssc = new StreamingContext(sparkcontext, Seconds(20))
  
    // stream to count words in new files created
    //val lines = ssc.textFileStream("hdfs://localhost:54310/user/hduser/streamdata/")
    ssc.checkpoint("checkpointdir")
    val lines = ssc.textFileStream("file:///home/hduser/sparkdata/streaming/")
    
    lines.count().print()
    val words = lines.flatMap(_.split(","))
    val wordCounts = words.map(x => (x, 1)).reduceByKey(_ + _)
      val updatedRdd= wordCounts.updateStateByKey(updateFunction)
    updatedRdd.print()
    ssc.start()
    ssc.awaitTermination()  
    
    
  }
}