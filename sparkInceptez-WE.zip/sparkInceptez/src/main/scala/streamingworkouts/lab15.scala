package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe


import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.HTable
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.client.{Put}
import org.apache.hadoop.hbase.client.Result
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.client.Get

import java.util.Properties
import java.sql.{Connection, DriverManager, ResultSet}

object lab15 {
  
  def main(args:Array[String])
  {
        val sparkConf = new SparkConf().setAppName("kafkahbase").setMaster("local[*]")
        val sparkcontext = new SparkContext(sparkConf)
        sparkcontext.setLogLevel("ERROR")
        
        val ssc = new StreamingContext(sparkcontext, Seconds(10))
        ssc.checkpoint("checkpointdir")
        val kafkaParams = Map[String, Object](
          "bootstrap.servers" -> "localhost:9092",
          "key.deserializer" -> classOf[StringDeserializer],
          "value.deserializer" -> classOf[StringDeserializer],
          "group.id" -> "kafkatest1",
          "auto.offset.reset" -> "earliest"
          )

        val topics = Array("kafkatopic")
        val stream = KafkaUtils.createDirectStream[String, String](
          ssc,
          PreferConsistent,
          Subscribe[String, String](topics, kafkaParams)
        )
        val kafkastream = stream.map(record => (record.key, record.value))
        val inputStream = kafkastream.map(rec => rec._2);
        
        inputStream.foreachRDD (rdd1 => 
          {
            if(!rdd1.isEmpty)
            {
              rdd1.foreachPartition(rdd => 
              {
                 val conf = HBaseConfiguration.create()
                 conf.set("hbase.zookeeper.quorum", "localhost:2181")
                 conf.set("hbase.master", "localhost:60000");
                 conf.set("hbase.rootdir", "file:///tmp/hbase")
                 val table = new HTable(conf, "tbltxns")
                 val rdd2 = rdd.map(x => 
                   {
                     val theget = new Get(Bytes.toBytes(x))
                     val result=table.get(theget)
                     TransRow.parseTransRow(result)
                   }                 
                 )
                 //rdd2.foreach(println)
                 //write into mysql
                 val conn = DriverManager.getConnection("jdbc:mysql://localhost/spark","root","root")
                 val del = conn.prepareStatement("INSERT INTO trans (transid,transdt,custid,salesamt,category,prodname,city,state,payment) VALUES (?,?,?,?,?,?,?,?,?)")
                 for (trans <- rdd2) {
                del.setString (1, trans.transid)
                del.setString(2, trans.transdate)
                del.setString(3, trans.custid)
                del.setFloat(4, trans.salesamt)
                del.setString(5, trans.category)
                del.setString(6, trans.prodname)
                del.setString(7, trans.city)
                del.setString(8, trans.state)
                del.setString(9, trans.payment)
                del.executeUpdate
                println("record inserted")
                 }
                 conn.close()
               })
              }
            }  
        );
        println("test")
        ssc.start()
        ssc.awaitTermination()
  }


case class transRow(transid: String, transdate: String, custid: String, salesamt: Float, category: String, prodname: String, state: String, city: String,payment: String)

  object TransRow extends Serializable {
    def parseTransRow(result: Result): transRow = {
      val rowkey = Bytes.toString(result.getRow())
      // remove time from rowKey, stats row key is for day
      val p0 = rowkey.split(" ")(0)
      val p1 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("txndate")))
      val p2 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("custid")))
      val p3 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("amount")))
      val p4 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("category")))
      val p5 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("prodname")))
      val p6 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("state")))
      val p7 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("city")))
      val p8 = Bytes.toString(result.getValue(Bytes.toBytes("trans"), Bytes.toBytes("payment")))
      transRow(p0, p1, p2, p3.toFloat, p4, p5, p6,p7,p8)
    }
  }
}