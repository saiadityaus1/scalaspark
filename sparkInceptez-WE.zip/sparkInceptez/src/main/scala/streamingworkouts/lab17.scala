package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SQLContext._
import StreamingContext._

object lab17 {
  
  case class empinfo(name:String,city:String,age:Integer)
  def main(args:Array[String])
  {
        val conf = new SparkConf().setAppName("jsonstring").setMaster("local[*]")
        val sc = new SparkContext(conf)
        sc.setLogLevel("ERROR")
        val ssc = new StreamingContext(sc, Seconds(10))
        val ds = ssc.socketTextStream("localhost", 9999)
        val sqlcontext = new SQLContext(sc)
        import sqlcontext.implicits._
        ds.foreachRDD(rdd =>{
          val df = sqlcontext.read.json(rdd)
          df.printSchema()
          df.show
        })        
        ssc.start()
        ssc.awaitTermination()
  }
}

//{"Rowid" :"row_1", "users" : { "firstname":"Rajesh","lastname":"Kumar","phone":"12345"}, "sites" : { "name": "gmail" } }

//{ "book": [{"id":"01","language": "Java","edition": "third","author": "Herbert Schildt"},{"id":"07","language": "C++","edition": "second","author": "E.Balagurusamy" }]}

//[{"id": 2,"name": "An ice sculpture","price": 12.50 },{"id": 3,"name": "A blue mouse","price": 25.50 }]