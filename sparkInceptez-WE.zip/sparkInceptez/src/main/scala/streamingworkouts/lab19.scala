package main.scala.streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.streaming._
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.dstream.ConstantInputDStream
import StreamingContext._
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import com.datastax.spark.connector.streaming._
import com.datastax.spark.connector._
import org.elasticsearch.spark._ 
import java.util.Properties
import java.text.SimpleDateFormat
import java.util.Date

object lab19 {
  
  def main(args:Array[String])
  {
        val sparkConf = new SparkConf().setAppName("kafkacassandra").setMaster("local[*]")
        sparkConf.set("es.nodes", "35.184.69.156")
        sparkConf.set("es.port", "9200")
        sparkConf.set("es.nodes.discovery", "false")
        sparkConf.set("es.nodes.data.only", "false")
        //for cloud, have to set wan only properties
        sparkConf.set("es.nodes.wan.only", "true")
        sparkConf.set("es.index.auto.create", "true");
        //sparkConf.set("es.mapping.id","prodid");
        val sparkcontext = new SparkContext(sparkConf)
        sparkcontext.setLogLevel("ERROR")
        val sqlContext = new SQLContext(sparkcontext)     
        val ssc = new StreamingContext(sparkcontext, Seconds(5))
        ssc.checkpoint("file:///tmp/checkpointdir")
        val kafkaParams = Map[String, Object](
          "bootstrap.servers" -> "localhost:9092",
          "key.deserializer" -> classOf[StringDeserializer],
          "value.deserializer" -> classOf[StringDeserializer],
          "group.id" -> "prodsalestopic1",
          "auto.offset.reset" -> "latest"
          )

        val topics = Array("prodsalestopic")
        val stream = KafkaUtils.createDirectStream[String, String](
          ssc,
          PreferConsistent,
          Subscribe[String, String](topics, kafkaParams)
        )
        val kafkastream = stream.map(record => (record.key, record.value))
        val kafkardd = kafkastream.map(rec => rec._2).map(_.split("\\|")).map(x => (x(0),(x(1),x(2))))
        val rdd = ssc.cassandraTable("inceptez", "productmaster").select("prodid","prodname","prodcat","supplier","salesprice","actualprice","prodstock")
        val dstream = new ConstantInputDStream(ssc,rdd)
        val ds1 = dstream.map(x => (x.getString(0),(x.getString(1),x.getString(2),x.getString(3),x.getString(4),x.getString(5),x.getString(6))))
        val ds2 = kafkardd.join(ds1)
        val dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var salesdt = new Date()
        //var  salesdt = dateFormatter.format(submittedDateConvert)
           
        val ds3 = ds2.map(x => prodsales(x._1.toInt,x._2._1._1.toInt,x._2._1._2.toFloat,x._2._2._1.toString,x._2._2._2.toString,x._2._2._3.toString,x._2._2._4.toFloat,x._2._2._5.toFloat,x._2._2._6.toInt,salesdt))
        ds3.foreachRDD(rdd => 
          {
              rdd.saveToEs("prodsales/doc")
          }
            
        )
        println("test")
        //ds3.saveToEs("prodsales/doc");
        ds3.print
        //println("test")
        ssc.start()
        ssc.awaitTermination()
  }
  
  case class prodsales(prodid:Int,quantity:Int,soldprice:Float,prodname:String,procategory:String,supplier:String,salesprice:Float,actualprice:Float,prodstock:Int,salesdt:Date)
}