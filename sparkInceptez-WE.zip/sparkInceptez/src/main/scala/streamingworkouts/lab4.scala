package streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._

object lab4 {
  
  def main(args:Array[String])
  {
   
    val sparkConf = new SparkConf().setAppName("wordcountwithupdatekey").setMaster("local[*]")
    val sparkcontext = new SparkContext(sparkConf)
    sparkcontext.setLogLevel("ERROR")
    // Create the context
    val virusRDD = sparkcontext.parallelize(Seq(("sr",1),("srini",2),("sujji",4),("virus",6)));
    val ssc = new StreamingContext(sparkcontext, Seconds(20))
  
    // stream to count words in new files created
    //val lines = ssc.textFileStream("hdfs://localhost:54310/user/hduser/streamdata/")
    ssc.checkpoint("checkpointdir")
    val lines = ssc.socketTextStream("localhost", 9999)
    val words = lines.flatMap(_.split(","))
    val wordCounts = words.map(x => (x, 1)).reduceByKey(_ + _)    
    val finalData = wordCounts.transform(x =>{x.join(virusRDD).sortBy(_._1, true); })
    finalData.print()
    ssc.start()
    ssc.awaitTermination()  
    
    
  }
}