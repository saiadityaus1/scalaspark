package streamingworkouts
import org.apache.spark.SparkConf
import  org.apache.spark.SparkContext
import org.apache.spark.streaming.{Seconds, StreamingContext}
import StreamingContext._
import java.util.Properties
import org.apache.spark.sql.SQLContext
import java.text.SimpleDateFormat
import java.util.Date

object lab6 {
  
  case class sales(categoryname:String,amount:Float,createddt:String)
  def main(args:Array[String])
  {
   
    val sparkConf = new SparkConf().setAppName("wordcountwithupdatekey").setMaster("local[*]")
    val sparkcontext = new SparkContext(sparkConf)
    val sqlContext = new SQLContext(sparkcontext)
    sparkcontext.setLogLevel("ERROR")
    // Create the context
    val ssc = new StreamingContext(sparkcontext, Seconds(5))
  
    // stream to count words in new files created
    //val lines = ssc.textFileStream("hdfs://localhost:54310/user/hduser/streamdata/")
    ssc.checkpoint("checkpointdir")
    val transactions = ssc.socketTextStream("localhost", 9999)
    val  transamt = transactions.map(x => x.split(",")).map(x => (x(4),x(3).toFloat))
    val wordCounts = transamt.reduceByKeyAndWindow((a:Float,b:Float)=>a+b, Seconds(20), Seconds(10))
    //wordCounts.print()
    wordCounts.foreachRDD(rdd=>
    {
      import sqlContext.implicits._
      if(!rdd.isEmpty)
      {
        val dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aa")
        var submittedDateConvert = new Date()
        var  crtdt = dateFormatter.format(submittedDateConvert)
        val df = rdd.map(x => sales(x._1,x._2,crtdt)).toDF()
        val prop = new Properties()
        prop.put("user", "root")
        prop.put("password", "root")
        df.write.mode("append").jdbc("jdbc:mysql://localhost/spark", "sales", prop)
        println("Data inserted into mysql database..")   
      }
    })    
    ssc.start()
    ssc.awaitTermination()
    
    
  }
}