package serverlog

import org.apache.spark._

object usecase5
{
  def main(args:Array[String])
  {
    //Usecase-5 -Get client OS count based on Windows,Linux, Android from $http_user_agent
    //sample data: 
    //157.50.34.148 - - [27/Dec/2016:19:12:15 +0530] "GET /api/broker/bseindex/?callback=angular.callbacks._1a HTTP/1.1" 200 305 "https://equityboss.com/dashboard/" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"  def main(args:Array[String])
  
    val conf = new SparkConf().setAppName("usecase5").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:///home/hduser/nginx/access.log",1)    
    val rdd1 = rdd.map(r =>
    {
      val sdata = r.split("\"")
      val osdata = sdata(5)
      (getos(osdata),1)
    }
    )
     val rdd2 = rdd1.reduceByKey(_+_).sortBy(x => x._2,false)     
     rdd2.foreach(println)    
  }
  
  def getos(s:String):String = {
  if(s.toUpperCase().contains("MACINTOSH"))
    "MACINTOSH"
  else if (s.toUpperCase().contains("WINDOWS"))
    "WINDOWS"
  else if (s.toUpperCase().contains("ANDROID"))
    "ANDROID"
    else
   "OTHERS"
}
  
}