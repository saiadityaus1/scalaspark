package main.scala.serverlog

import org.apache.spark._

object usecase3 
{
  //Usecase-3 - Get $status http response code count
  //sample data: 
  //157.50.34.148 - - [27/Dec/2016:19:12:15 +0530] "GET /api/broker/bseindex/?callback=angular.callbacks._1a HTTP/1.1" 200 305 "https://equityboss.com/dashboard/" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"  def main(args:Array[String])
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setAppName("usecase3").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:///home/hduser/nginx/access.log")    
    val rdd1 = rdd.map(r =>
    {
      val indstart = r.indexOf("\"")
      val indend = r.indexOf(" ",indstart+1)
      val stcodestrpos = r.indexOf("\"",indstart+1)
      val method = r.substring(indstart + 1,indend+1)
      val statuscode = r.substring(stcodestrpos+2, stcodestrpos+5)
      val methodstatuscode = method.trim().concat("-" + statuscode.trim())
      (methodstatuscode,1)
    }
    )
      val rdd2 = rdd1.countByKey()
      rdd2.foreach(println)    
  }
  
}