package main.scala.serverlog

import org.apache.spark._

object usecase22 
{
  //Usecase-2 - Get count of HTTP-Method(GET,POST,HEAD,etc) from $remote_user
  //sample data: 
  //157.50.34.148 - - [27/Dec/2016:19:12:15 +0530] "GET /api/broker/bseindex/?callback=angular.callbacks._1a HTTP/1.1" 200 305 "https://equityboss.com/dashboard/" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"  def main(args:Array[String])
  
  def main(args:Array[String])
  {
    val conf = new SparkConf().setAppName("usecase2").setMaster("local")
    val sc = new SparkContext(conf)
    sc.setLogLevel("ERROR")
    val rdd = sc.textFile("file:///home/hduser/nginx/access.log")    
    val rdd1 = rdd.map(processdata)
      val rdd2 = rdd1.countByKey()
      rdd2.foreach(println)    
  }
  
  def processdata(r:String):(String,Int) = 
  {
     val indstart = r.indexOf("\"",0)
     val indend = r.indexOf(" ",indstart+1)
      val method = r.substring(indstart + 1,indend+1)
      return (method.trim(),1)
      
  }
  
  val processdata1 = (r:String) => {
    
     val indstart = r.indexOf("\"")
      val indend = r.indexOf(" ",indstart+1)
      val stcodestrpos = r.indexOf("\"",indstart+1)
      val method = r.substring(indstart + 1,indend+1)
      (method.trim(),1)
  }  
  
}